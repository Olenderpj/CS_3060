//
// Created by PJ Olender on 8/26/22.
//

#ifndef HW_6_18_OLENDER_OUTPUTUTILITIES_H
#define HW_6_18_OLENDER_OUTPUTUTILITIES_H

// format the final output of all calculated results
void formatOutput(double paintRequired, double laborHours, double paintCost, double laborCost);

#endif //HW_6_18_OLENDER_OUTPUTUTILITIES_H
